import logging
import azure.functions as func
from azure.storage.blob import BlobClient
from azure.cosmos import CosmosClient
from datetime import datetime
import mimetypes

def main(event: func.EventGridEvent):
    logging.info('Event Grid event received.')

    data = event.get_json()
    url = data['url']
    blob_name = data['subject'].split('/')[-1]
    container_name = data['subject'].split('/')[1]

    # Download blob
    blob_client = BlobClient.from_blob_url(url)
    blob_data = blob_client.download_blob().readall()

    # Detect title and word count if text
    content_type, _ = mimetypes.guess_type(blob_name)
    title = ""
    word_count = 0

    if content_type and content_type.startswith("text"):
        text = blob_data.decode('utf-8')
        lines = text.splitlines()
        title = lines[0] if lines else ""
        word_count = len(text.split())

    # Prepare document
    document = {
        "id": blob_name,
        "url": url,
        "size": len(blob_data),
        "title": title,
        "wordCount": word_count,
        "uploadedOn": datetime.utcnow().isoformat()
    }

    # Insert into Cosmos DB
    cosmos_uri = "<your_cosmos_uri>"
    cosmos_key = "<your_cosmos_primary_key>"
    database_name = "DocumentDB"
    container_name = "Documents"

    client = CosmosClient(cosmos_uri, credential=cosmos_key)
    container = client.get_database_client(database_name).get_container_client(container_name)

    try:
        container.create_item(document)
        logging.info(f"Document {blob_name} inserted into Cosmos DB.")
    except Exception as e:
        logging.error(f"Error inserting document: {e}")
